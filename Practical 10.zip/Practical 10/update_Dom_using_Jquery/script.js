$(document).ready(function() {
    $('#changeButton').click(function() {
        $('#message').text('Text changed using jQuery!');
    });
});

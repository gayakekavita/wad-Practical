const http = require("http");


const myserver=http.createServer((req,res)=>{
  console.log("New Req Rec.");
  res.end("Hello From Server");
       });

myserver.listen(8000, () => console.log("Server started")); 






/*
1...        npm.init
enter and make by difult "yes"
it create 'package.json' file which contain basic scripting and configuration.

2..create index.js file which shows the entry point 
we have one built in module in js  known as "http"
const http = require("http");
const myserver=http.createServer #create our own server 
to handle incoming request we have one handler function known as  requestListener [callback function]((req,res)=>{})
req stores meta data of user such ip or whom all
res  helps to send response to that user ]((req,res)=>{console.log("New Req Rec.");
  res.end("Hello From Server");});

we need one port number to listen request(run server) myserver.listen(8000,()=>consol.log("Server started"));  if all work properly then we give this callback function

go in package.jason and write one script "scripts":{"start":"node index"},

npm start in terminal
go in browser
type locahost:8000

ctrl+c close server
when we work with req we have multiple things to do 
1. consol.log(req.header); ##store loclhost metada
2. consol.log(req); # which client,browser,ip address in short whome how what


const fs = requir("fs");

const myserver=http.createServer((req,res)=>{const log='${date.now()}:new Req Recived\n'; 
fs.appendFile('log.text",log,(err,data)=>{res.end("hello from server");});


start again with npm start 


*/